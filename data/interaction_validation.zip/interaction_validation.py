import urllib.request
import json

read = open('input.txt')
line=read.readline()

while line: #一行一行读取测试数据
 loc=line.index('\'')
 loc1=line.index('\'',loc+1) #找到第一个和第二个‘的位置
 loc2=line.index('\'',loc1+1) #第三个'
 loc3=line.index('\'',loc2+1) #第四个'
 GeneName = line[loc+4:loc1] #获得基因名,+4是因为hsa都是一样的
 DrugName = line[loc2+1:loc3] #获得药物名
 #print(GeneName)
 #print(DrugName)
 sname = 'http://www.genome.jp/dbget-bin/www_bget?hsa:'+GeneName #访问基因的网页的url
 #print(sname)
 response = urllib.request.urlopen(sname).read().decode('utf-8') #将网页转换成字符串
 #loc = response.index('Gene name')
 #name = response[loc+176:loc+186]
 #locEnd = name.index(',')
 #FirstName = name[0:locEnd]
 #print(FirstName)
 #print(response.find(DrugName))
 uniLoc = response.find('uniprot/')
 uniLoc1 = response.find('/',uniLoc+1)
 uniLoc2 = response.find('\"',uniLoc+1)
 uniProt = response[uniLoc1+1:uniLoc2] #得到uniprot的名称
 #print(uniProt)
 if response.find(DrugName) != -1: #开始搜索基因的网页
  print('KEGG')
 else : 
  sname1 = 'http://www.kegg.jp/dbget-bin/www_bget?'+DrugName #访问药物的网页的url（KEGG）
  #print(sname1)
  response1 = urllib.request.urlopen(sname1).read().decode('utf-8') #将网页转换成字符串
  DBloc = response1.find('drugbank')
  if(DBloc == -1) :
   print('N/A')
  else :
   DBloc1 = response1.find('\"',DBloc+1)
   RestUrl = response1[DBloc:DBloc1]
   DBUrl = 'http://www.'+RestUrl #获得drugbank的url
   #print(DBUrl)
   DBres = urllib.request.urlopen(DBUrl).read().decode('utf-8') #转换成字符串
   if DBres.find(uniProt) != -1:
    print('DRUGBANK')
   else :
    print('N/A')
  
#  print('N/A')
 line= read.readline()
read.close
