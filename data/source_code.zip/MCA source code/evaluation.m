function [ prec,tpr,thresh,F ] = evaluation( score,target)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
score=score/max(score);
thresh=unique(score);
prec = zeros(length(thresh),1);
tpr  = zeros(length(thresh),1);
total_target=sum(target);
for i = 1:length(thresh)
    idx     =find (score >= thresh(i));
    tpr(i)  = sum(target(idx)) / total_target;
    prec(i) = sum(target(idx)) / length(idx);
end
F=2*(prec.*tpr)./(prec+tpr);
end

