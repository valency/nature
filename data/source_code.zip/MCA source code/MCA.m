function [ SVTresult,svtF1,svtprc,svtrec,svtthr,svtAUC] = MCA( M1,K,Indices )
M=M1*10+2;
%M=M1;
n_target = length(M(:,1));
n_drug = length(M(1,:));

for num=1:K
    [ train,test,trainIdx,testIdx ] = datagene( M,Indices,num);
    data = M(trainIdx);
    if ~isreal(M), disp('Matrix is complex'); end
    tau = 5*sqrt(n_target*n_drug);
    delta = 1.5;
    maxiter = 500;
    tol = 1e-5;
    fprintf('\nSolving by SVT...\n');
    tic
    [U,S,V,numiter] = SVT([n_target n_drug],trainIdx,data,tau,delta,maxiter,tol);
    toc
    X = U*S*V';
    temp=Indices;
    temp(temp~=num)=0;
    temp(temp~=0)=1;
    test2=reshape(temp,[n_target,n_drug]);
    test2=X.*test2;
    score=X(:);
    score=score(testIdx);
    score=(score-min(score))/(max(score)-min(score));
    target=test(:);
    target=target(testIdx);
    target(target==2)=0;
    target(target==12)=1;
    [ prec,tpr,thresh,F ] = evaluation( score,target);
    svtF1(num)=max(F);
    Idx=find(F==max(F));
    svtprc(num)=prec(Idx(1));
    svtrec(num)=tpr(Idx(1));
    svtthr(num)=thresh(Idx(1));
    [svtXpr,svtYpr,svtTpr,svtAUC(num)] = perfcurve(target, score, 1);
    SVTresult(num)=struct('Link',X,'test',test,'test2',test2,'testIdx',testIdx,'train',train,'trainIdx',trainIdx);
end
end

