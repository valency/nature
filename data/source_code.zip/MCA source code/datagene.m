function [ train,test,trainIdx,testIdx ] = datagene( M,Indices,num )
% generate trainset and testset
[n_target,n_drug]=size(M);

trainIdx=Indices;
testIdx=Indices;

trainIdx(trainIdx==num)=0;
trainIdx(trainIdx~=0)=1;
train=reshape(trainIdx,[n_target,n_drug]);
train=M.*train;

testIdx(testIdx~=num)=0;
testIdx(testIdx~=0)=1;
test=reshape(testIdx,[n_target,n_drug]);
test=M.*test;

trainIdx = find(Indices~=num);
testIdx=find(Indices==num);
end

