% This is the MCA demo
% Reference: Predicting Hidden Interactions between Known Drugs and Targets via Matrix Completion
M1=importdata('data/nr_admat_dgc.txt');
M1=M1.data;
K=10;
% 10-fold cross validation
Indices=crossvalind('Kfold',M1(:),K);

%=========Method=========
% SVT method only use interaction matrix
[SVTresult,svtF1,svtprc,svtrec,svtthr,svtAUC] = MCA( M1,K,Indices );

% NBI method only use interaction matrix
[NBIresult,nbiF1,nbiprc,nbirec,nbithr,nbiAUC] = NBI( M1,K,Indices );

% KBMF2K method use interaction, drug, target similarity
[KBMFresult,kbmfF1,kbmfprc,kbmfrec,kbmfthr,kbmfAUC ] = KBMF2K( M1,Indices,K );

% GIP method use interaction, drug, target similarity
[~,GIPresult]=cross_validate(@predict_rls_cg2,'nr','kernel','given','num_folds',10,'num_repetitions',1,'stddevs',1,'negatives',-1,'rows',1,'merge',1);

% NetLapRLs use interaction, drug, target, similarity. Build in R
[netF1,netprc,netrec,netthr,netAUC ] = NetLapRLs( 1,K,'e' );
[SVTresult2,svtF12,svtprc2,svtrec2,svtthr2,svtAUC2] = MCA2( M1,K,0.9 );
